function MapDisplay(){
    return(
        <>
        <div id="map" style={{ width: "100%", height: "700px" }}></div>
        </>
    )
}
export default MapDisplay;